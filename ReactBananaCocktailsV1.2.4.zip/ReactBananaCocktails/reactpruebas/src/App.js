//import './App.css';
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Inicio from "./screens/InicioL";
import Tienda from "./screens/Tienda";
import Login from "./screens/Login";
import Register from './screens/Register';
import AdminHome from './screens/AdminHome';

function App() {

  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(
    sessionStorage.getItem('isAdminLoggedIn') === 'true'
  );


  useEffect(() => {
    // Puedes realizar acciones adicionales cuando isAdminLoggedIn cambie
    console.log('isAdminLoggedIn en app.js:', isAdminLoggedIn);
  }, [isAdminLoggedIn]); 

  return (

    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<Inicio />} />
          <Route path="/inicio" element={<Inicio />} />
          <Route path="/tienda" element={<Tienda />} />
          {/* <Route path="/tienda/:id/*"
            element={(isClientLoggedIn ? <Tienda /> : <Navigate to="/tienda" />
            )}
          /> */}
          <Route path="/login" element={<Login />} />
          <Route path='/register' element={<Register />} />
          {/* Solo para Administrador */}
          <Route
            path="/adminHome/*"
            element={(
              isAdminLoggedIn ? <AdminHome /> : <Navigate to="/login" />
            )}
          />

        </Routes>
      </Router>
    </div>
  );
}



export default App;
