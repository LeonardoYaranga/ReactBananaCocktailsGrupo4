import React, { useState, useEffect } from 'react';
import CompShowClientes from '../components/cliente/ShowClientes';
import { Routes, Route } from 'react-router-dom';
import CreateCliente from "../components/cliente/CreateCliente";
import EditCliente from "../components/cliente/EditCliente";
import AdditionalGIF from '../Images/Iconos/carga.gif';
import '../styles/GestionClientes.css'; 

const GestionClientes = () => {
  const [showAdditionalGif, setShowAdditionalGif] = useState(true);
  const [showTable, setShowTable] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowAdditionalGif(false);
      setShowTable(true);
    }, 3500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="body-GestionClientes">
      {showAdditionalGif && (
        <div className="additional-gif-container"> 
          <img src={AdditionalGIF} alt="Additional GIF" />
        </div>
      )}
      {showTable && (
        <>
          <center>
            <h1 className="h1-GestionClientes">Gestión de Clientes</h1>
          </center>
          <Routes>
            <Route path="/createCliente" element={<CreateCliente />} />
            <Route path="/editCliente/:id" element={<EditCliente />} />
          </Routes>
          <CompShowClientes />
        </>
      )}
    </div>
  );
}

export default GestionClientes;