import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import CompShowCocteles from '../components/coctel/ShowCocteles';
import CreateCoctel from '../components/coctel/CreateCoctel';
import EditCoctel from '../components/coctel/EditCoctel';
import AdditionalGIF from '../Images/Iconos/xarga2.gif';
import '../styles/GestionCocteles.css'; // Importar estilos CSS

const GestionCocteles = () => {
  const [showAdditionalGif, setShowAdditionalGif] = useState(true);
  const [showTable, setShowTable] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowAdditionalGif(false);
      setShowTable(true);
    }, 2500); 

    return () => clearTimeout(timer);
  }, []);

  return (
    <div>
      {showAdditionalGif && (
        <div className="additional-gif-container"> 
          <img src={AdditionalGIF} alt="Additional GIF" />
        </div>
      )}
      {showTable && (
        <>
          <center>
            <h1 className="h1-GestionCocteles">Gestión de Cócteles</h1>
          </center>
          <Routes>
            <Route path="/createCoctel" element={<CreateCoctel />} />
            <Route path="/editCoctel/:id" element={<EditCoctel />} />
          </Routes>
          <CompShowCocteles />
        </>
      )}
    </div>
  );
}

export default GestionCocteles;