import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import CompShowSecciones from '../components/seccion/ShowSecciones';
import CreateSeccion from '../components/seccion/CreateSeccion';
import EditSeccion from '../components/seccion/EditSeccion';
import AdditionalGIF from '../Images/Iconos/seccion.gif';
import '../styles/GestionSecciones.css'; // Importar estilos CSS

const GestionSecciones = () => {
  const [showAdditionalGif, setShowAdditionalGif] = useState(true);
  const [showTable, setShowTable] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowAdditionalGif(false);
      setShowTable(true);
    }, 3800);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div>
      {showAdditionalGif && (
        <div className="additional-gif-container"> 
          <img src={AdditionalGIF} alt="Additional GIF" />
        </div>
      )}
      {showTable && (
        <>
          <center>
            <h1 className="h1-GestionSecciones">Gestión de Secciones</h1>
          </center>
          <Routes>
            <Route path="/createSeccion" element={<CreateSeccion />} />
            <Route path="/editSeccion/:id" element={<EditSeccion />} />
          </Routes>
          <CompShowSecciones />
        </>
      )}
    </div>
  );
}

export default GestionSecciones;