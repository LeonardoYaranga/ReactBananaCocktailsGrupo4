import React, { useState } from 'react';
import { Route, Routes, Link, useLocation } from 'react-router-dom';
import GestionCocteles from './GestionCocteles';
import GestionClientes from './GestionClientes';
import { useNavigate } from 'react-router-dom';
import GestionSecciones from './GestionSecciones';
import '../styles/AdminHome.css';

import AdminHomeGIF from '../Images/Iconos/AdminHome.gif';

const AdminHome = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [botonPresionado, setBotonPresionado] = useState(false);

    const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(
        sessionStorage.getItem('isAdminLoggedIn') === 'true'
    );

    const adminLogout = () => {
        sessionStorage.setItem('isAdminLoggedIn', 'false');
        setIsAdminLoggedIn(false);
        navigate('/login');
    };
    
    const isGestionRoute = location.pathname.includes('/adminHome/gestion');

    return (
        <div className="body-AdminHome">
            <center>
                <h2 className="h2-AdminHome">¡Bienvenido, administrador!</h2>
                <nav className="nav nav-pills flex-column flex-sm-row nav-AdminHome" >
                    <Link to="/adminHome/gestionClientes" className="flex-sm-fill text-sm-center nav-link text-bg-success p-3" aria-current="page" onClick={() => setBotonPresionado(true)} style={{ fontFamily: 'Rockwell, sans-serif' }}>
                        <i className='fas fa-edit' /> Gestionar Clientes
                    </Link>
                    <Link to="/adminHome/gestionCocteles" className='flex-sm-fill text-sm-center nav-link text-bg-warning p-3' onClick={() => setBotonPresionado(true)} style={{ fontFamily: 'Rockwell, sans-serif' }}>
                        <i className='fas fa-edit' /> Gestionar Cócteles
                    </Link>
                    <Link to="/adminHome/gestionSecciones" className='flex-sm-fill text-sm-center nav-link text-bg-info p-3' onClick={() => setBotonPresionado(true)} style={{ fontFamily: 'Rockwell, sans-serif' }}>
                        <i className='fas fa-edit' /> Gestionar Secciones
                    </Link>
                    <button onClick={adminLogout} className='btn btn-danger flex-sm-fill text-sm-center' style={{ fontFamily: 'Rockwell, sans-serif' }}><i className="fa-solid fa-right-from-bracket"></i> Cerrar sesión</button>
                </nav>
                
                {!isGestionRoute && <img className="img-AdminHome" src={AdminHomeGIF} alt="GIF" />}
            </center>
            
            <Routes>
                <Route path="/gestionClientes/*" element={<GestionClientes />} />
                <Route path='/gestionSecciones/*' element={<GestionSecciones />} />
                <Route path="/gestionCocteles/*" element={<GestionCocteles />} />
            </Routes>
        </div>
    );
}

export default AdminHome;