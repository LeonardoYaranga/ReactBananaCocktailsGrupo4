import axios from 'axios';
import { useState, useEffect } from 'react';
import ShowTabla from '../ShowTabla';

const URI = 'http://localhost:8000/';

const CompShowClientes = () => {
    const [clientes, setClientes] = useState([]);
    const [columnas, setColumnas] = useState([]);

    const [searchTerm, setSearchTerm] = useState('');
    const [activos, setActivos] = useState(true);

    const getClientes = async () => {
        let url = `${URI}cliente/`;
        if (activos) {
            //url para todos los clientes
            url = `${URI}cliente/`;
            //url para buscar por nombre
            if (searchTerm) {
                // Si hay un término de búsqueda, modificar la URL para buscar por nombre
                url = `${URI}clienteNombreActivo/${searchTerm}`;
            }
        } else {
            //url para todos los clientes inactivos
            url = `${URI}clienteInactivo/`;
            //url para buscar por nombre
            if (searchTerm) {
                // Si hay un término de búsqueda, modificar la URL para buscar por nombre   
                url = `${URI}clienteNombreInactivo/${searchTerm}`;
            }
        }
        //peticion
        const res = await axios.get(url);
        if (res && res.data) {
            setClientes(res.data);

            // Obtener las columnas únicas
            const uniqueColumns = Array.from(
                new Set(res.data.flatMap((cliente) => Object.keys(cliente)))
            );
            setColumnas(uniqueColumns);
        }
    };

    useEffect(() => {
        getClientes();
    }, [searchTerm, activos]);
    useEffect(() => {
        console.log('Activos:', activos);
    }, [activos]);

    const deleteCliente = async (IDCLIENTE) => {
        await axios.put(`${URI}desactivarCliente/${IDCLIENTE}`);
        getClientes();
    }


    return (
        <div>
            <nav className="navbar navbar-light bg-info">
                <form className="form-inline d-flex mx-auto ">
                    <div className="input-group">
                        <div className="input-group-prepend d-flex">
                            <span className="input-group-text" id="basic-addon1">@</span>
                        </div>
                        <input type="text"
                            className="form-control"
                            placeholder="Username"
                            aria-label="Username"
                            aria-describedby="basic-addon1"
                            style={{ width: '300px' }}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="d-flex align-items-center justify-content-between mx-3">
                        <div className="btn-group btn-group-toggle" data-toggle="buttons">
                            <label className="btn btn-primary">
                                <input
                                    type="radio"
                                    name="options"
                                    id="option1"
                                    autoComplete="off"
                                    checked={activos}
                                    onChange={() => {
                                        setActivos(true);
                                    }}
                                />
                                Activos
                            </label>
                            <label className="btn btn-secondary">
                                <input
                                    type="radio"
                                    name="options"
                                    id="option2"
                                    autoComplete="off"
                                    checked={!activos}
                                    onChange={() => {
                                        setActivos(false);
                                    }}
                                />
                                Inactivos
                            </label>
                        </div>
                    </div>
                </form>
            </nav>

            <ShowTabla
                linkCrear="/adminHome/gestionClientes/createCliente"
                linkEditar="/adminHome/gestionClientes/editCliente"
                funcionBorrar={deleteCliente}
                columnas={columnas}
                datos={clientes}
                idDatos="IDCLIENTE"
            />
        </div>
    );
};

export default CompShowClientes;