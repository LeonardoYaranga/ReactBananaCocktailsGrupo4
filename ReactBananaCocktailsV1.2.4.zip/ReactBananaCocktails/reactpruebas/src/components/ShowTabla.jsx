import React from 'react'
import { Link } from 'react-router-dom';
import '../styles/ShowTabla.css';
const ShowTabla = (props) => {
    
    return (

        <div className='container ShowTabla'>
            <div className='row '>
                <div className='col'>

                    <Link to={`${props.linkCrear}`} className='btn btn-primary mt-2 mb-2'><i className="fas fa-plus"></i></Link>
                    <div className='table-responsive '>
                        <table className='table'>
                            <thead className='table-success'>
                                <tr>
                                    {props.columnas.map((columna) => (
                                        <th key={columna}>{columna}</th>
                                    ))}
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody className='table-warning'>
                                {props.datos.map((dato) => (
                                    <tr key={dato[props.idDatos]}>
                                        {props.columnas.map((columna) => (
                                            <td key={columna}>{dato[columna]}</td>
                                        ))}
                                        <td>
                                            <center>
                                                <Link to={`${props.linkEditar}/${dato[props.idDatos]}`} className='btn btn-info'><i className='fas fa-edit' /></Link>
                                                <button onClick={() => props.funcionBorrar(dato[props.idDatos])} className='btn btn-danger'><i className='fas fa-trash-alt' /></button>
                                            </center>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default ShowTabla
