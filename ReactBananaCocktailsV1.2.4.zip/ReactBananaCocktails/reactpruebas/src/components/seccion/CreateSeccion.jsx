import React from 'react'
import axios from "axios";
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { validarCampo, validarSoloLetras } from '../../scripts/validacion';

const URI = 'http://localhost:8000/seccion/'

const CreateSeccion = () => {
    const [nombreSeccion, setNombreSeccion] = useState('');
    const [activaSec, setActivaSec] = useState(true);
    const navigate = useNavigate();

    const store = async (e) => {
        e.preventDefault()
        try {
            await axios.post(URI, { NOMBRESEC: nombreSeccion, ACTIVASEC: activaSec });
            navigate('/adminHome/gestionSecciones');
            window.location.reload();
        } catch (error) {
            console.error('Error al crear la seccion', error.response.data);
            alert(error.response.data);
        }
    }


    return (
        <div>
            <h3>Nueva Seccion</h3>
            <form onSubmit={store}>
                <div className="mb-3">
                    <label className="form-label">NOMBRE SECCION</label>
                    <input
                        value={nombreSeccion}
                        type="text"
                        name='nombre'
                        id='nombreSeccion'
                        pattern="[A-Za-z]+"
                        maxLength="100"
                        onKeyPress={(event) => validarSoloLetras(event)}
                        onInput={(e) => validarCampo(e.target)}
                        onChange={(e) => setNombreSeccion(e.target.value)}
                        className="form-control"
                        required
                    />
                </div>
                <center>
                    <button type='submit' className='btn btn-primary'>Crear</button>
                </center>
            </form>
        </div>
    )
}

export default CreateSeccion
