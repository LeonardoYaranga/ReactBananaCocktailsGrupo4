import React from 'react'
import axios from 'axios';
import { useState, useEffect } from 'react';
import ShowTabla from '../ShowTabla';

const URI = 'http://localhost:8000/';


const ShowSecciones = () => {
  const [secciones, setSecciones] = useState([]);
  const [columnas, setColumnas] = useState([]);


  const [searchTerm, setSearchTerm] = useState('');
  const [activos, setActivos] = useState(true);

  const getSecciones = async () => {
    let url = `${URI}seccion/`;
    if (activos) {
      //url para todas las secciones
      url = `${URI}seccion/`;
      //url para buscar por nombre
      if (searchTerm) {
        // Si hay un término de búsqueda, modificar la URL para buscar por nombre
        url = `${URI}seccionNombreActivo/${searchTerm}`;
      }
    } else {
      //url para todas las secciones inactivas
      url = `${URI}seccionInactiva/`;
      //url para buscar por nombre
      if (searchTerm) {
        // Si hay un término de búsqueda, modificar la URL para buscar por nombre
        url = `${URI}seccionNombreInactivo/${searchTerm}`;
      }
    }
    //peticion
    const res = await axios.get(url);
    if (res && res.data) {
      setSecciones(res.data);

      // Obtener las columnas únicas
      const uniqueColumns = Array.from(
        new Set(res.data.flatMap((seccion) => Object.keys(seccion)))
      );
      setColumnas(uniqueColumns);
    }
  };
  useEffect(() => {
    getSecciones();
  }, [searchTerm, activos]);

  useEffect(() => {
    console.log('Activos:', activos);
  }, [activos]);
  const deleteSeccion = async (IDSECCION) => {
    await axios.put(`${URI}desactivarSeccion/${IDSECCION}`);
    getSecciones();
  }


  return (
    <div>
      <nav className="navbar navbar-light bg-info">
        <form className="form-inline d-flex mx-auto ">
          <div className="input-group">
            <div className="input-group-prepend d-flex">
              <span className="input-group-text" id="basic-addon1">@</span>
            </div>
            <input type="text"
              className="form-control"
              placeholder="Nombre Seccion"
              aria-label="Nombre Seccion"
              aria-describedby="basic-addon1"
              style={{ width: '300px' }}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="d-flex align-items-center justify-content-between mx-3">
            <div className="btn-group btn-group-toggle" data-toggle="buttons">
              <label className="btn btn-primary">
                <input
                  type="radio"
                  name="options"
                  id="option1"
                  autoComplete="off"
                  checked={activos}
                  onChange={() => {
                    setActivos(true);
                  }}
                />
                Activos
              </label>
              <label className="btn btn-secondary">
                <input
                  type="radio"
                  name="options"
                  id="option2"
                  autoComplete="off"
                  checked={!activos}
                  onChange={() => {
                    setActivos(false);
                  }}
                />
                Inactivos
              </label>
            </div>
          </div>
        </form>
      </nav>


      <ShowTabla
        linkCrear="/adminHome/gestionSecciones/createSeccion"
        linkEditar="/adminHome/gestionSecciones/editSeccion"
        funcionBorrar={deleteSeccion}
        columnas={columnas}
        datos={secciones}
        idDatos="IDSECCION"

      />
    </div>
  );
}

export default ShowSecciones


