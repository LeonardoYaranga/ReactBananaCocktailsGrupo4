import React from 'react'
import axios from "axios";
import { validarCampo, validarSoloLetras } from '../../scripts/validacion';
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const URI = 'http://localhost:8000/seccion/';

const EditSeccion = () => {
  const [nombreSeccion, setNombreSeccion] = useState('');
  const [activaSec, setActivaSec] = useState(true);
  const navigate = useNavigate();
  const { id } = useParams();

  const update = async (e) => {
    e.preventDefault();
    await axios.put(URI + id, {
      NOMBRESEC: nombreSeccion,
      ACTIVASEC: activaSec
    })

    navigate('/adminHome/gestionSecciones');
    window.location.reload();
  }

  useEffect(() => {
    getSeccionById();
  }, []);

  const getSeccionById = async () => {
    try {
      const res = await axios.get(URI + id)
      const seccion = res.data[0];
      setNombreSeccion(seccion.NOMBRESEC);
    } catch (error) {
      console.error('Error al obtener la seccion en el frontend', error);
    }
  }


  return (
    <div>
      <h3>Actualizando Seccion</h3>
      <form onSubmit={update}>
        <div className="mb-3">
          <label className="form-label">NOMBRE SECCION</label>
          <input
            value={nombreSeccion}
            type="text"
            name='nombre'
            id='nombreSeccion'
            pattern="[A-Za-z]+"
            maxLength="100"
            onKeyPress={(event) => validarSoloLetras(event)}
            onInput={(e) => validarCampo(e.target)}
            onChange={(e) => setNombreSeccion(e.target.value)}
            className="form-control"
            required
          />
        </div>
        <center>
          <button type='submit' className='btn btn-primary'>Editar</button>
        </center>
      </form>
    </div>
  )
}

export default EditSeccion
