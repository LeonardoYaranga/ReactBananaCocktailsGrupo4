import React from 'react'
import axios from 'axios';
import { useState, useEffect } from 'react';
import ShowTabla from '../ShowTabla';
const URI = 'http://localhost:8000/';

const ShowCocteles = () => {
    const [cocteles, setCocteles] = useState([]);
    const [columnas, setColumnas] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [activos, setActivos] = useState(true);
    const [seccionesActivas, setSeccionesActivas] = useState([]);
    const [idSeccion, setIdSeccion] = useState(0);

    const getCocteles = async () => {
        let url = `${URI}coctel/`;
        if (activos) {
            //url para todos los cocteles
            url = `${URI}coctel/`;
            //url para buscar por nombre
            if (searchTerm) {
                // Si hay un término de búsqueda, modificar la URL para buscar por nombre
                url = `${URI}coctelNombreActivo/${searchTerm}`;
            }
            if (idSeccion > 0) {
                url = `${URI}coctelActivoSeccion/${idSeccion}`;
            }

        } else {
            //url para todos los cocteles inactivos
            url = `${URI}coctelInactivo/`;
            //url para buscar por nombre
            if (searchTerm) {
                // Si hay un término de búsqueda, modificar la URL para buscar por nombre
                url = `${URI}coctelNombreInactivo/${searchTerm}`;
            }
            if (idSeccion > 0) {
                url = `${URI}coctelInactivoSeccion/${idSeccion}`;
            }
        }
        //peticion 
        const res = await axios.get(url);
        if (res && res.data) {
            setCocteles(res.data);

            // Obtener las columnas únicas
            const uniqueColumns = Array.from(
                new Set(res.data.flatMap((coctel) => Object.keys(coctel)))
            );
            setColumnas(uniqueColumns);
        }
    }

    useEffect(() => {
        getCocteles();
    }, [searchTerm, activos, idSeccion]);

    useEffect(() => {
        console.log('Activos:', activos);
    }, [activos]);

    const deleteCoctel = async (IDCOCTEL) => {
        await axios.put(`${URI}desactivarCoctel/${IDCOCTEL}`);
        getCocteles();
    }

    //cargar opciones  de busqueda por secciones
    const getSeccionesActivas = async () => {
        try {
            const res = await axios.get('http://localhost:8000/seccion/');
            if (res && res.data) {
                // Mapear la respuesta para obtener solo el nombre y el id
                const secciones = res.data.map(seccion => ({
                    id: seccion.IDSECCION,
                    nombre: seccion.NOMBRESEC
                }));
                // Actualizar el estado con las secciones mapeadas
                setSeccionesActivas(secciones);
            }
        } catch (error) {
            console.error('Error al obtener secciones activas:', error);
        }
    }

    useEffect(() => {
        getSeccionesActivas();
    }, []);


    useEffect(() => {
        console.log('IdSEccion:', idSeccion);
    }, [idSeccion]);

    return (
        <div>
            <div className="d-flex align-items-center justify-content-between mx-2">
                <nav className="navbar navbar-light bg-info mx-auto">
                    <form className="form-inline d-flex align-items-center justify-content-between w-100">

                        <input
                            className="form-control mr-sm-2 mx-3 rounded bg-light"
                            type="search"
                            placeholder="Search"
                            aria-label="Search"
                            style={{ width: '300px' }}
                            onChange={(e) => {
                                setSearchTerm(e.target.value)
                                setIdSeccion(0);
                            }}
                        />
                        <span className="input-group-text">
                            <i className='fas fa-search' />
                        </span>
                        <div className="d-flex align-items-center justify-content-between mx-3">
                            <div className="btn-group btn-group-toggle" data-toggle="buttons">
                                <label className="btn btn-primary">
                                    <input
                                        type="radio"
                                        name="options"
                                        id="option1"
                                        autoComplete="off"
                                        checked={activos}
                                        onChange={() => {
                                            setActivos(true);
                                            setIdSeccion(0);
                                        }}
                                    />
                                    Activos
                                </label>

                                <label className="btn btn-secondary">
                                    <input
                                        type="radio"
                                        name="options"
                                        id="option2"
                                        autoComplete="off"
                                        checked={!activos}
                                        onChange={() => {
                                            setActivos(false);
                                            setIdSeccion(0);
                                        }}
                                    />
                                    Inactivos
                                </label>
                            </div>
                            <label className="form-label mx-4">Seccion</label>
                            <select
                                value={idSeccion}
                                className='form-control btn btn-outline-success bg-warning '
                                onChange={(e) => setIdSeccion(e.target.value)}
                                required
                            >
                                <option value="0">Todas</option>
                                {seccionesActivas.map(seccion => (
                                    <option key={seccion.id} value={seccion.id}>
                                        {seccion.nombre}
                                    </option>
                                ))}
                            </select>

                        </div>
                    </form>

                </nav>
            </div>

            <ShowTabla
                linkCrear="/adminHome/gestionCocteles/createCoctel"
                linkEditar="/adminHome/gestionCocteles/editCoctel"
                funcionBorrar={deleteCoctel}
                columnas={columnas}
                datos={cocteles}
                idDatos="IDCOCTEL"
            />
        </div >
    )
}

export default ShowCocteles
