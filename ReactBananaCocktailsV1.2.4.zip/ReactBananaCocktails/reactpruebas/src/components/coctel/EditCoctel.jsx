import React from 'react'
import axios from "axios";
import { validarCampo, validarSoloLetras, validarSoloNumeros } from '../../scripts/validacion';
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const URI = 'http://localhost:8000/coctel/';


const EditCoctel = () => {

    const [idSeccion, setIdSeccion] = useState('');
    const [idAdministrador, setIdAdministrador] = useState(1);//por ahora solo hay un administrador
    const [nombreCoctel, setNombreCoctel] = useState('');
    const [descripcionCoctel, setDescripcionCoctel] = useState('');
    const [precioCoctel, setPrecioCoctel] = useState('');
    const [imagenCoctel, setImagenCoctel] = useState('');
    const [activoCoctel, setActivoCoctel] = useState(true);//por defecto el coctel está activo [1
    const navigate = useNavigate();
    const { id } = useParams();
    const [seccionesActivas, setSeccionesActivas] = useState([]);

    const update = async (e) => {
        e.preventDefault();
        await axios.put(URI + id, {
            IDSECCION: idSeccion,
            IDADMINISTRADOR: idAdministrador,
            NOMBREC: nombreCoctel,
            DESCRIPCIONC: descripcionCoctel,
            PRECIOUNITARIOC: precioCoctel,
            IMAGENC: imagenCoctel,
            ACTIVOC: activoCoctel
        });

        navigate('/adminHome/gestionCocteles');
        window.location.reload();
    }

    useEffect(() => {
        getCoctelById();
    }, []);

    const getCoctelById = async () => {
        try {
            const res = await axios.get(URI + id)
            const coctel = res.data[0];
            setIdSeccion(coctel.IDSECCION);
            setNombreCoctel(coctel.NOMBREC);
            setDescripcionCoctel(coctel.DESCRIPCIONC);
            setPrecioCoctel(coctel.PRECIOUNITARIOC);
            setImagenCoctel(coctel.IMAGENC);
            setActivoCoctel(coctel.ACTIVOC);
        } catch (error) {
            console.error('Error al obtener el coctel en el frontend', error);
        }
    }

    const getSeccionesActivas = async () => {
        try {
            const res = await axios.get('http://localhost:8000/seccion/');
            if (res && res.data) {
                // Mapear la respuesta para obtener solo el nombre y el id
                const secciones = res.data.map(seccion => ({
                    id: seccion.IDSECCION,
                    nombre: seccion.NOMBRESEC
                }));
                // Actualizar el estado con las secciones mapeadas
                setSeccionesActivas(secciones);
            }
        } catch (error) {
            console.error('Error al obtener secciones activas:', error);
        }
    }

    useEffect(() => {
        getSeccionesActivas();
    }, []);


    useEffect(() => {
        console.log('IdSEccion:', idSeccion);
    }, [idSeccion]);

    return (
        <div>
            <h3>Editar Coctel</h3>
            <form onSubmit={update}>
                <div className="mb-3">
                    <label className="form-label">SECCION</label>
                    <select value={idSeccion} className='form-control'
                     onChange={(e) => setIdSeccion(e.target.value)}
                     required
                     >
                        {seccionesActivas.map(seccion => (
                            <option key={seccion.id}
                                value={seccion.id}
                            >
                                {seccion.nombre}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="mb-3">
                    <label className="form-label">NOMBRE COCTEL</label>
                    <input
                        value={nombreCoctel}
                        type="text"
                        name='nombre'
                        id='nombreCoctel'
                        pattern="[A-Za-z ]+"
                        maxLength="100"
                        onKeyPress={(event) => validarSoloLetras(event)}
                        onInput={(e) => validarCampo(e.target)}
                        onChange={(e) => setNombreCoctel(e.target.value)}
                        className="form-control"
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">DESCRIPCION COCTEL</label>
                    <input
                        value={descripcionCoctel}
                        type="text"
                        name='descripcion'
                        id='descripcionCoctel'
                        pattern="[A-Za-z\u00E1\u00E9\u00ED\u00F3\u00FA\u00FC\u00F1\u00C1\u00C9\u00CD\u00D3\u00DA\u00DC\u00D1,.:;'\-\s]+"
                        maxLength="490"
                        //onKeyPress={(event) => validarSoloLetras(event)}
                        //onInput={(e) => validarCampo(e.target)}
                        onChange={(e) => setDescripcionCoctel(e.target.value)}
                        className="form-control"
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">PRECIO COCTEL</label>
                    <input
                        value={precioCoctel}
                        type="number"
                        name='precio'
                        id='precioCoctel'
                        pattern="[0-9]+"
                        maxLength="3"
                        onKeyPress={(event) => validarSoloNumeros(event)}
                        onInput={(e) => validarCampo(e.target)}
                        onChange={(e) => setPrecioCoctel(e.target.value)}
                        className="form-control"
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">IMAGEN COCTEL</label>
                    <input
                        value={imagenCoctel}
                        type="text"
                        name='imagen'
                        id='imagenCoctel'
                        pattern="[A-Za-z\u00E1\u00E9\u00ED\u00F3\u00FA\u00FC\u00F1\u00C1\u00C9\u00CD\u00D3\u00DA\u00DC\u00D1,.:;'\-\s]+"
                        maxLength="100"
                        //onKeyPress={(event) => validarSoloLetras(event)}
                        //onInput={(e) => validarCampo(e.target)}
                        onChange={(e) => setImagenCoctel(e.target.value)}
                        className="form-control"
                        required
                    />
                </div>
                <center>
                    <button type='submit' className='btn btn-primary'>Editar</button>
                </center>
            </form>
        </div>
    )
}

export default EditCoctel
